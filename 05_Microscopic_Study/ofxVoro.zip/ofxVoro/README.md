![Image](http://patriciogonzalezvivo.com/2013/ofxvoro/image.png)

[OpenFrameworks addon](https://github.com/patriciogonzalezvivo/ofxVoro) for [Voro++](http://math.lbl.gov/voro++/about.html) made by Chris H. Rycroft (LBL / UC Berkeley) <chr@alum.mit.edu>

# Installation

Clone this [addon](https://github.com/patriciogonzalezvivo/ofxVoro) into your `openFrameworks/addons` by

	cd openFrameworks/addons
	git clone https://github.com/patriciogonzalezvivo/ofxVoro

<iframe src="http://player.vimeo.com/video/64697511" width="575" height="323" frameborder="0" webkitAllowFullScreen mozallowfullscreen allowFullScreen></iframe>

<iframe src="http://player.vimeo.com/video/64520422" width="575" height="323" frameborder="0" webkitAllowFullScreen mozallowfullscreen allowFullScreen></iframe>
		